NOURISHMIND — COMPLETE PROJECT HANDOFF (Updated 7 April 2026)

LIVE URL: https://nourishmind-rho.vercel.app
GitHub: https://github.com/ArpadApps/Nourishmind
Local: C:\Users\Arpad\Desktop\nourishmind
Stack: React + Vite, Anthropic API (claude-sonnet-4-20250514 for scans, claude-opus-4-6 for chat, claude-haiku-4-5-20251001 for memory extraction + food detection)
Code editor: Cursor (agent mode)
Owner: Arpad Toth, autónomo, Ibiza, Spain
Contact: arpadibiza@gmail.com / legal.nourishmind@gmail.com
GitHub username: ArpadApps


GIT SAVE POINTS

35d9b88 — Pre-label scanner baseline (Noor voice improvements, DAILY_CAP = 20)
b98cc15 — First working label scanner
Latest commit — Fully polished label scanner with all fixes


WHAT WAS DONE IN SESSION 7 APRIL 2026

Food Journal — Backend Built and Working

The food journal is a structured data layer underneath the existing chat. Noor silently detects food mentions and logs them with dates and meal context. The journal is fed into Noor's system prompt so she can spot patterns over days and weeks. The user never leaves the chat.

What was built:
- Journal utilities: loadJournal, buildJournalEntry, persistJournalEntry, updateJournalEntry, deleteJournalEntry, getRecentJournal — stored in localStorage under noor-food-journal
- Haiku extraction expanded: the existing extractMemoryUpdate function now asks Haiku to detect food alongside memory in one call (max_tokens bumped to 512)
- Recent conversation context (last 4 messages) passed to Haiku so single-word food replies ("broccoli", "rice") are detected in context
- Food detection covers past, present, AND future tense ("I had eggs", "having steak", "I'll have chicken tonight")
- Multi-exchange meal combining: Haiku instructed to combine food items across exchanges into one entry
- Journal entries (last 14 days) fed into Noor's system prompt via buildSystemPrompt third parameter
- Noor's system prompt includes guidance on using journal data naturally (never say "food journal", never announce logging)
- Private mode guard: entire extraction (memory + food) skipped when private mode is on
- Journal respects free/pro split (journal is a Pro feature — free tier has no memory)
- 90-day rolling retention, 500 entry max, auto-pruning on write

What is TEMPORARY:
- Food auto-saves directly to journal without user confirmation. This is a placeholder.
- The correct UX (not yet built) is a header notification approach: journal icon gets a gold dot when food is detected, user taps it whenever they want, sees pending meals in a slide-up panel, confirms or discards.

What was tried and removed:
- Inline "Log it / Skip" buttons below Noor's replies — felt too mechanical, interrupted conversation flow
- Buffer/accumulator logic to wait for meal completion — fragile, unreliable timing
- Counter-based flush (wait for 2 non-food exchanges) — glitchy

Food Journal Spec (locked):
- Each entry: date (YYYY-MM-DD), meal (breakfast/lunch/dinner/snack/unspecified), items (array of strings), notes (optional context)
- Haiku distinguishes REPORTING (user says what they ate/are eating/plan to eat → log it) from ASKING (user asks what they ate before → do NOT log)
- Only food the USER mentions gets logged, never food Noor suggests
- FoodLogPrompt component exists in the file (not rendered) — will be repurposed for the notification panel

Private Mode Messages Added:
- Switching TO private mode: Noor says "Private session. Nothing from here carries forward."
- Switching FROM private mode: Noor says "I'll remember again."
- Both are visual-only messages — not sent to API, not counted toward daily limit


LABEL SCANNER FIXES (from separate thread, may or may not be applied yet)

Two issues identified:
1. Scan responses too long/alarming — leading with negatives, exceeding 100 words, disproportionate warnings (e.g., lecturing about salt in sardines). Fix: reinforce original spec in scan prompt — lead with positives, be proportionate, never shame food, hard 100 word max.
2. Scan results not in apiHistory — Noor cannot reference a label scan in subsequent chat messages because the scan analysis is displayed but not added to apiHistory. Fix: add both a synthetic user message and the scan response to apiHistory after scan completes.

STATUS: Cursor prompts were written for both fixes. Check if they have been applied. If not, apply them.


WORKING FEATURES (complete list as of 7 April 2026)

Noor AI companion responding live on Vercel (scanner and journal NOT yet deployed)
Secure API proxy via /api/chat serverless function
Local dev uses VITE_ANTHROPIC_API_KEY directly when hostname is localhost
Message cap: 20/day (DAILY_CAP = 20), resets at local midnight, stored in localStorage
Label scanner with Product Shelf (full flow working locally)
Scan cap: 2/day (DAILY_SCAN_CAP = 2), resets at local midnight, stored in localStorage
Food journal backend (auto-save, detection, system prompt integration — working locally)
Terms of Service and Privacy Policy pages with footer links
localStorage memory — Noor remembers user info across sessions
Memory extracted after every exchange via extractMemoryUpdate (Haiku)
Private mode: no memory passed, no memory extraction, no food extraction, no memory in scans
Private mode toggle messages ("Private session..." / "I'll remember again.")
LED status dot: green (ready), amber (typing), red (limit reached)
Memory toggle in header with dropdown
Send pulse animation
Mobile layout: 100dvh, messages anchor to bottom
Rotated opening messages (8 variations)


DESIGN — UNCHANGED

Background: #0e0d0c
Gold accent: #c8a97e
Cream text: #e8ddd0
Georgia serif for headlines
Noor avatar: noor-avatar.png
Scan buttons: gold "Taking it", transparent bordered "Leaving it", 44px min height


NOOR'S CHARACTER — UNCHANGED

All previous voice rules still apply. Never recommend brand names. Teach what to look for on labels. Respect canned/packaged choices. No banned phrases. Calibration example embedded in scan prompt.


MONETISATION — UNCHANGED

Free tier (permanent): 5 messages/day, 2 label scans/day, no memory, no journal
Pro: $7.99/month or $59.99/year — 30 messages/day, 15 label scans/day, full memory, weekly insights, food journal, protocol builder


KNOWN BUGS

1. LED dot colour: should be green when idle, currently appears amber/bronze. Amber should only show when Noor is typing.
2. Chat gap on live Vercel site (works locally, gap persists on deployed version)
3. NM logo rendering issue ("Nou" text appearing beside icon in header)
4. Noor occasionally exceeds word limits in scan responses
5. Label scan results not in apiHistory — Noor forgets scans in subsequent messages (fix written, may not be applied)


TECHNICAL NOTES

Deploying to Vercel: Cursor agent mode → "In the terminal, run: npx vercel --prod"
Local dev: Cursor agent mode → "In the terminal, run: npm run dev"
Local dev on phone: Cursor agent mode → "In the terminal, run: npm run dev -- --host" then use the Network URL shown
Reset scan count: localStorage.removeItem('noor_scans_count');localStorage.removeItem('noor_scans_date');location.reload()
Reset message count: localStorage.removeItem('noor_messages_count');localStorage.removeItem('noor_messages_date');location.reload()
Reset food journal: localStorage.removeItem('noor-food-journal');location.reload()
Anthropic spend cap: $50/month, auto-recharge $20 when below $5


IMPORTANT PREFERENCES (always follow these)

Arpad is a complete beginner — explain clearly before instructing
Always verify technical information before giving instructions
Never send Arpad to install or use anything without confirming it exists and works on Windows
Make all technical decisions yourself — do not ask Arpad to choose on unfamiliar technical matters
Always put code instructions inside copyable code blocks
Before touching any code, always read the relevant files first so instructions are precise
Work on one thing at a time — do not stack changes
Always show proposed changes before applying when using Cursor
Never deploy to Vercel without first removing any dev/test buttons or debug code
Code editor is Cursor in agent mode — all instructions go there, not command prompt


PRE-LAUNCH BUILD SCOPE (locked April 2026)

Ship only: chat + journal + Weekly Insights + Label Scanner/Product Shelf + Supabase + Stripe
No Protocol Builder or other features until these are bulletproof and launched
Mobile polish is critical
Weekly Insights is #1 priority after the big test


WHAT TO PASTE AT START OF NEXT THREAD

Paste ONLY this handoff document. Say which task number you are working on from the master task list. Claude's memory system stores additional context. This handoff plus memory plus the task number gives full continuity.
