NOURISHMIND — MASTER TASK LIST (Updated 7 April 2026)

One thread = one task. Paste the handoff doc + say "working on task X."


═══════════════════════════════════════════════════════════════════
CRITICAL BUGS (fix before anything else)
═══════════════════════════════════════════════════════════════════

1. Label scan not in apiHistory — Noor forgets scans in subsequent messages. Scan analysis must be added to apiHistory so Noor can reference it. Fix written, may not be applied yet.

2. LED dot colour — shows amber/bronze when idle, should be green. Amber only when Noor is typing.


═══════════════════════════════════════════════════════════════════
FOOD JOURNAL (resume building)
═══════════════════════════════════════════════════════════════════

3. Journal confirmation UX — Build the header notification approach:
   - Add a journal icon to the header
   - Gold notification dot appears when Haiku detects food
   - Tapping opens a slide-up panel showing pending meals
   - User confirms (saves to journal) or discards each entry
   - Replace current auto-save with pending queue → user confirms flow
   - Chat stays completely clean — no inline buttons

4. Journal viewer — read-only scrollable view of confirmed journal entries (last 14 days), accessible from the same panel or a separate view. Secondary to task 3.


═══════════════════════════════════════════════════════════════════
LABEL SCANNER POLISH
═══════════════════════════════════════════════════════════════════

5. Tighten scan response quality — Reinforce original spec in scan prompt: lead with positives, be proportionate, never shame food, hard 100 word max. Fix written, may not be applied yet.

6. Test scan + chat continuity — After task 1 is done, verify that scanning a label and then asking Noor about it in the next message works.


═══════════════════════════════════════════════════════════════════
COSMETIC / UI FIXES
═══════════════════════════════════════════════════════════════════

7. Chat gap on live Vercel site — gap at top of chat that doesn't appear locally.

8. NM logo rendering — "Nou" text appearing beside icon in header.

9. Mobile polish pass — test on phone via --host, fix any layout/touch issues.


═══════════════════════════════════════════════════════════════════
FEATURES (build in this order)
═══════════════════════════════════════════════════════════════════

10. Weekly Insight Drops — notification pulling from journal + shelf + chat patterns. #1 priority feature after journal is solid.

11. Deploy to Vercel — all local features (scanner, journal) pushed live. Remove any dev/test buttons first.

12. Supabase — user accounts and authentication. Must come before Stripe.

13. Stripe — payments tied to accounts.

14. Free/Pro tier enforcement — gate features by subscription status.

15. Custom domain — connect nourishmind.app (Porkbun) to Vercel.


═══════════════════════════════════════════════════════════════════
PARKED (not until everything above is shipped)
═══════════════════════════════════════════════════════════════════

- Personal protocol builder
- Location awareness
- Any other new features
